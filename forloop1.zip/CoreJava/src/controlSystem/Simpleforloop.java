package controlSystem;

public class Simpleforloop {
	public static void main(String[] args) {
		// code of for loop
		int i;
		for(i=1; i<=10; i++)
		{ //iteration 10 time
			System.out.println("the output is :"+i);
		}
	}

}
