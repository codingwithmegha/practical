package com.megha.batch4199.springboot.user.project.UserProjectBatch4119;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserProjectBatch4119ApplicationTests {

	@Test
	void contextLoads() {
	}

}
