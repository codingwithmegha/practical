package com.megha.batch4199.springboot.user.project.UserProjectBatch4119;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserProjectBatch4119Application {

	public static void main(String[] args) {
		SpringApplication.run(UserProjectBatch4119Application.class, args);
	}

}
