package controlSystem;

public class Dowhile1 {
	public static void main(String[] args) {
		int i=1;
		do {
			System.out.println("hello");
			i++;
		}
		while(i<=10);
		
	}

}
