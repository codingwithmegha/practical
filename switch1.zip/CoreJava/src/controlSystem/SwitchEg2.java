package controlSystem;

public class SwitchEg2 {
	public static void main(String[] args) {
int no=10;
switch(no)
{
case 1:
	System.out.println("20");
break;
case 2:
	System.out.println("10");
break;
case 3:
	System.out.println("40");
break;
case 10:
	System.out.println("50");
break;

default:System.out.println("invalid number");
}
	}
}



