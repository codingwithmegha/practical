package controlSystem;

public class Dowhile3 {
	public static void main(String[] args) {
		
		int i=2;
		System.out.println("First 10 even number");
		do {
			System.out.println(i);
			i=i+2;
		}while(i<=10);

		}

}
