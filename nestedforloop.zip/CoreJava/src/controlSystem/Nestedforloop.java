package controlSystem;

public class Nestedforloop {
	public static void main(String[] args) {
		// code of for loop
		int i,j;
		for(i=1; i<=10; i++)
			for(j=10; j<=20; j++)
		{ //iteration 10 time
			
			System.out.println("the output is :"+i+" "+j);
		}
	}



}
